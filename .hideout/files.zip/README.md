# 📊 就活IRダッシュボード

就活生が志望企業の財務データを一覧で比較するためのStreamlitダッシュボード。

## 機能

- 就活ティアリスト企業の財務情報をyfinance経由で自動取得
- 企業カード形式で時価総額・売上高・営業利益率・年収等を一覧表示
- ティア別フィルタリング、各種ソート機能
- 1時間キャッシュで高速表示

## セットアップ

```bash
pip install -r requirements.txt
streamlit run app.py
```

## 技術スタック

- Python 3.12+
- Streamlit
- yfinance
- Pandas

## 今後の拡展予定

- [ ] 売上・利益推移の時系列チャート
- [ ] セクター別比較ビュー
- [ ] 選考状況メモ機能
- [ ] React + FastAPI でのフルスタック版への移植

## ライセンス

MIT
